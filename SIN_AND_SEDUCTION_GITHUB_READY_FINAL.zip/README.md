# 🖤 SIN & SEDUCTION: OMNI-EDITION (MASTER CORE)

Esta es la versión definitiva del núcleo técnico para el MMORPG más ambicioso y oscuro de GitHub.

## 🌀 Sistemas Integrados (Omni-Engine)

1.  **Motor de Regiones Dinámicas:** El mundo se divide en zonas que requieren niveles de corrupción específicos. Si no eres lo suficientemente oscuro, los "Jardines de la Lujuria" o el "Vacío de la Traición" te consumirán.
2.  **Sistema de Reliquias de Sangre:** Inventario gestionado por puertas de corrupción. Artefactos que escalan tu poder basados en tus pecados.
3.  **Clanes de Sangre:** Estructura social para que los jugadores se agrupen, aunque el motor permite la traición interna entre miembros del mismo clan.
4.  **IA de Invasión Global:** Eventos programados donde el servidor genera oleadas de NPCs predadores para purgar el mapa.
5.  **Persistencia SQL & WebSockets:** Sincronización instantánea de eventos globales y guardado automático en PostgreSQL.

## 🛠 Instalación Rápida
- **Lenguaje:** Kotlin 1.9
- **Database:** Ejecutar `SinAndSeduction_Persistence.sql`
- **Build:** `./gradlew shadowJar` para generar el ejecutable del servidor.

---
*Developed by ShacktarMalacky - Sin is the only path to power.*
