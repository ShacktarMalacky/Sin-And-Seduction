package com.shacktar.sinandseduction.engine
import java.util.*

fun main(args: Array<String>) {
    val engine = SinEngine()
    val p1 = engine.spawn("Shacktar")
    val p2 = engine.spawn("Rival_01")
    val p3 = engine.spawn("Seductress_X")

    println("--- INICIANDO SIMULACIÓN DE MUNDO ---")
    
    repeat(10) { i ->
        val action = (0..2).random()
        when (action) {
            0 -> engine.attack(p1, p2)
            1 -> engine.betray(p2, p3)
            2 -> engine.attack(p3, p1)
        }
    }

    println("\n--- ESTADO FINAL DEL MUNDO ---")
    engine.entities.values.forEach { 
        println("${it.name} [${it.path}] -> Money: ${it.money.toInt()} | Infamy: ${it.infamy} | HP: ${it.hp.toInt()}")
    }
}
